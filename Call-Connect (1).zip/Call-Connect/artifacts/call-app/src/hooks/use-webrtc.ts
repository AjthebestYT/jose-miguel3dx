import { useState, useEffect, useRef, useCallback } from "react";

export type ConnectionState =
  | "idle"
  | "connecting"
  | "waiting"
  | "in-call"
  | "call-ended"
  | "error";

export interface RemotePeer {
  stream: MediaStream;
  userName: string;
}

export interface ChatMessage {
  id: string;
  from: string;
  userName: string;
  text: string;
  timestamp: number;
  isSelf: boolean;
}

interface UseWebRTCProps {
  roomCode: string;
  userName: string;
}

const ICE_SERVERS = [
  { urls: "stun:stun.l.google.com:19302" },
  { urls: "stun:stun1.l.google.com:19302" },
];

export function useWebRTC({ roomCode, userName }: UseWebRTCProps) {
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [remoteStreams, setRemoteStreams] = useState<Map<string, RemotePeer>>(new Map());
  const [connectionState, setConnectionState] = useState<ConnectionState>("idle");
  const [error, setError] = useState<string | null>(null);
  const [isMuted, setIsMuted] = useState(false);
  const [isCameraOff, setIsCameraOff] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);

  const wsRef = useRef<WebSocket | null>(null);
  const localStreamRef = useRef<MediaStream | null>(null);
  // Map of peerId -> RTCPeerConnection
  const peerConnectionsRef = useRef<Map<string, RTCPeerConnection>>(new Map());
  // Map of peerId -> userName
  const peerNamesRef = useRef<Map<string, string>>(new Map());
  const myPeerIdRef = useRef<string | null>(null);
  const wsKeepAliveRef = useRef<number | null>(null);

  const clearWebSocketKeepAlive = useCallback(() => {
    if (wsKeepAliveRef.current !== null) {
      window.clearInterval(wsKeepAliveRef.current);
      wsKeepAliveRef.current = null;
    }
  }, []);

  const addRemotePeer = useCallback((peerId: string, stream: MediaStream, peerUserName: string) => {
    setRemoteStreams((prev) => {
      const next = new Map(prev);
      next.set(peerId, { stream, userName: peerUserName });
      return next;
    });
  }, []);

  const removeRemotePeer = useCallback((peerId: string) => {
    setRemoteStreams((prev) => {
      const next = new Map(prev);
      next.delete(peerId);
      return next;
    });
    const pc = peerConnectionsRef.current.get(peerId);
    if (pc) {
      pc.close();
      peerConnectionsRef.current.delete(peerId);
    }
    peerNamesRef.current.delete(peerId);
  }, []);

  const createPeerConnection = useCallback((peerId: string) => {
    const existing = peerConnectionsRef.current.get(peerId);
    if (existing) return existing;

    const pc = new RTCPeerConnection({ iceServers: ICE_SERVERS });

    pc.onicecandidate = (event) => {
      if (event.candidate && wsRef.current?.readyState === WebSocket.OPEN) {
        wsRef.current.send(
          JSON.stringify({
            type: "ice-candidate",
            to: peerId,
            candidate: event.candidate,
          })
        );
      }
    };

    pc.ontrack = (event) => {
      if (event.streams?.[0]) {
        const peerUserName = peerNamesRef.current.get(peerId) || "Unknown";
        addRemotePeer(peerId, event.streams[0], peerUserName);
        if (connectionState !== "in-call") {
          setConnectionState("in-call");
        }
      }
    };

    pc.onconnectionstatechange = () => {
      if (pc.connectionState === "failed" || pc.connectionState === "closed") {
        removeRemotePeer(peerId);
      }
    };

    // Add local tracks so remote peer can receive our stream
    const stream = localStreamRef.current;
    if (stream) {
      stream.getTracks().forEach((track) => pc.addTrack(track, stream));
    }

    peerConnectionsRef.current.set(peerId, pc);
    return pc;
  }, [addRemotePeer, removeRemotePeer, connectionState]);

  const stopAllTracks = useCallback(() => {
    localStreamRef.current?.getTracks().forEach((t) => t.stop());
    localStreamRef.current = null;
    setLocalStream(null);
  }, []);

  const leaveCall = useCallback(() => {
    clearWebSocketKeepAlive();
    stopAllTracks();
    peerConnectionsRef.current.forEach((pc) => pc.close());
    peerConnectionsRef.current.clear();
    peerNamesRef.current.clear();
    setRemoteStreams(new Map());
    if (wsRef.current) {
      wsRef.current.close();
      wsRef.current = null;
    }
    setConnectionState("call-ended");
  }, [clearWebSocketKeepAlive, stopAllTracks]);

  const toggleMute = useCallback(() => {
    const stream = localStreamRef.current;
    if (!stream) return;
    const tracks = stream.getAudioTracks();
    const newEnabled = !tracks[0]?.enabled;
    tracks.forEach((t) => { t.enabled = newEnabled; });
    setIsMuted(!newEnabled);
  }, []);

  const toggleCamera = useCallback(() => {
    const stream = localStreamRef.current;
    if (!stream) return;
    const tracks = stream.getVideoTracks();
    const newEnabled = !tracks[0]?.enabled;
    tracks.forEach((t) => { t.enabled = newEnabled; });
    setIsCameraOff(!newEnabled);
  }, []);

  const initializeMedia = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: true,
      });
      localStreamRef.current = stream;
      setLocalStream(stream);
      return stream;
    } catch {
      setError("Failed to access camera/microphone.");
      return null;
    }
  }, []);

  const sendChatMessage = useCallback((text: string) => {
    const trimmed = text.trim();
    if (!trimmed || !wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) return;
    wsRef.current.send(JSON.stringify({ type: "chat", text: trimmed }));
    // Add own message locally
    setMessages((prev) => [
      ...prev,
      {
        id: `self-${Date.now()}`,
        from: myPeerIdRef.current || "self",
        userName,
        text: trimmed,
        timestamp: Date.now(),
        isSelf: true,
      },
    ]);
  }, [userName]);

  const connect = useCallback(async () => {
    if (!roomCode || !userName) return;

    setConnectionState("connecting");

    if (!localStreamRef.current) {
      const stream = await initializeMedia();
      if (!stream) {
        setConnectionState("error");
        return;
      }
    }

    const wsProtocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${wsProtocol}//${window.location.host}/api/ws`;
    const ws = new WebSocket(wsUrl);
    wsRef.current = ws;

    ws.onopen = () => {
      ws.send(JSON.stringify({ type: "join", roomCode, userName }));
      setConnectionState("waiting");

      // Keep the signaling socket active. Some proxies close otherwise-idle
      // WebSocket connections after a few minutes even while media is flowing
      // peer-to-peer on a separate connection.
      clearWebSocketKeepAlive();
      wsKeepAliveRef.current = window.setInterval(() => {
        if (ws.readyState === WebSocket.OPEN) {
          ws.send(JSON.stringify({ type: "keepalive" }));
        }
      }, 20_000);
    };

    ws.onmessage = async (event) => {
      try {
        const msg = JSON.parse(event.data as string);

        switch (msg.type) {
          case "welcome": {
            // Server assigned us a peerId and gave us the existing peers list
            myPeerIdRef.current = msg.peerId;
            const peers: { id: string; userName: string }[] = msg.peers || [];

            if (peers.length > 0) {
              setConnectionState("in-call");
            }

            // Initiate a connection to every existing peer
            for (const peer of peers) {
              peerNamesRef.current.set(peer.id, peer.userName);
              const pc = createPeerConnection(peer.id);
              const offer = await pc.createOffer();
              await pc.setLocalDescription(offer);
              ws.send(
                JSON.stringify({ type: "offer", to: peer.id, sdp: offer })
              );
            }
            break;
          }

          case "user-joined": {
            // A new peer joined; they will send us an offer, just store their name
            peerNamesRef.current.set(msg.peerId, msg.userName);
            break;
          }

          case "user-left": {
            removeRemotePeer(msg.peerId);
            if (peerConnectionsRef.current.size === 0) {
              setConnectionState("waiting");
            }
            break;
          }

          case "offer": {
            // Existing peer is initiating a connection to us
            const { from, sdp } = msg;
            if (!peerNamesRef.current.has(from)) {
              // Shouldn't happen but guard anyway
              peerNamesRef.current.set(from, "Unknown");
            }
            const pc = createPeerConnection(from);
            await pc.setRemoteDescription(new RTCSessionDescription(sdp));
            const answer = await pc.createAnswer();
            await pc.setLocalDescription(answer);
            ws.send(JSON.stringify({ type: "answer", to: from, sdp: answer }));
            setConnectionState("in-call");
            break;
          }

          case "answer": {
            const { from, sdp } = msg;
            const pc = peerConnectionsRef.current.get(from);
            if (pc) {
              await pc.setRemoteDescription(new RTCSessionDescription(sdp));
            }
            break;
          }

          case "ice-candidate": {
            const { from, candidate } = msg;
            const pc = peerConnectionsRef.current.get(from);
            if (pc) {
              await pc.addIceCandidate(new RTCIceCandidate(candidate));
            }
            break;
          }

          case "chat": {
            setMessages((prev) => [
              ...prev,
              {
                id: `${msg.from}-${msg.timestamp}`,
                from: msg.from as string,
                userName: msg.userName as string,
                text: msg.text as string,
                timestamp: msg.timestamp as number,
                isSelf: false,
              },
            ]);
            break;
          }

          case "error": {
            setError(msg.message || "Server error");
            setConnectionState("error");
            break;
          }
        }
      } catch (err) {
        // Silently ignore parse errors
      }
    };

    ws.onerror = () => {
      setError("Connection failed. Please try again.");
      setConnectionState("error");
    };

    ws.onclose = () => {
      clearWebSocketKeepAlive();
      // Media can continue peer-to-peer if signaling briefly drops, so do not
      // end the call here. The heartbeat keeps normal connections alive.
    };
  }, [
    roomCode,
    userName,
    initializeMedia,
    createPeerConnection,
    removeRemotePeer,
    clearWebSocketKeepAlive,
  ]);

  useEffect(() => {
    return () => {
      leaveCall();
    };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  return {
    localStream,
    remoteStreams,
    connectionState,
    error,
    isMuted,
    isCameraOff,
    messages,
    initializeMedia,
    connect,
    leaveCall,
    toggleMute,
    toggleCamera,
    sendChatMessage,
  };
}
