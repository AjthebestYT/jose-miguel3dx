import { useState } from "react";
import { useLocation } from "wouter";
import { useCreateRoom, useListRooms, getListRoomsQueryKey } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Video, Plus, Users, ArrowRight, X, Loader2, RefreshCw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

// ─── Create room modal ─────────────────────────────────────────────────────────

function CreateRoomModal({ onClose }: { onClose: () => void }) {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const createRoom = useCreateRoom();
  const [roomName, setRoomName] = useState("");
  const [hostName, setHostName] = useState("");

  const handleCreate = () => {
    if (!roomName.trim()) { toast({ title: "Room name required", variant: "destructive" }); return; }
    if (!hostName.trim()) { toast({ title: "Your name is required", variant: "destructive" }); return; }

    createRoom.mutate(
      { data: { hostName: hostName.trim(), roomName: roomName.trim() } },
      {
        onSuccess: (room) => {
          sessionStorage.setItem("callConnectUserName", hostName.trim());
          setLocation(`/room/${room.code}`);
        },
        onError: () => {
          toast({ title: "Error", description: "Could not create room. Please try again.", variant: "destructive" });
        },
      }
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-sm bg-zinc-900 border border-white/10 rounded-2xl shadow-2xl p-6 space-y-5 animate-in zoom-in-95 duration-200">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-white">Create a Room</h2>
          <button onClick={onClose} className="text-white/40 hover:text-white transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4">
          <div className="space-y-1.5">
            <label className="text-sm font-medium text-white/70">Room Name</label>
            <Input
              autoFocus
              placeholder="e.g. Team Standup"
              value={roomName}
              onChange={(e) => setRoomName(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleCreate()}
              className="h-11 bg-white/5 border-white/10 text-white placeholder:text-white/30"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-sm font-medium text-white/70">Your Name</label>
            <Input
              placeholder="How others see you"
              value={hostName}
              onChange={(e) => setHostName(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleCreate()}
              className="h-11 bg-white/5 border-white/10 text-white placeholder:text-white/30"
            />
          </div>
        </div>

        <div className="flex gap-2 pt-1">
          <Button variant="ghost" className="flex-1 h-11 text-white/60 hover:text-white" onClick={onClose}>
            Cancel
          </Button>
          <Button className="flex-1 h-11" onClick={handleCreate} disabled={createRoom.isPending}>
            {createRoom.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : "Create Room"}
          </Button>
        </div>
      </div>
    </div>
  );
}

// ─── Join modal ────────────────────────────────────────────────────────────────

function JoinModal({ roomCode, roomName, participantCount, onClose }: {
  roomCode: string;
  roomName: string;
  participantCount: number;
  onClose: () => void;
}) {
  const [, setLocation] = useLocation();
  const [name, setName] = useState("");
  const [error, setError] = useState("");

  const handleJoin = () => {
    if (!name.trim()) { setError("Please enter your name."); return; }
    sessionStorage.setItem("callConnectUserName", name.trim());
    setLocation(`/room/${roomCode}`);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-sm bg-zinc-900 border border-white/10 rounded-2xl shadow-2xl p-6 space-y-5 animate-in zoom-in-95 duration-200">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-white">{roomName}</h2>
            <p className="text-xs text-white/40 mt-0.5">
              {participantCount} {participantCount === 1 ? "person" : "people"} in call
            </p>
          </div>
          <button onClick={onClose} className="text-white/40 hover:text-white transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-1.5">
          <label className="text-sm font-medium text-white/70">Your Name</label>
          <Input
            autoFocus
            placeholder="How others see you"
            value={name}
            onChange={(e) => { setName(e.target.value); setError(""); }}
            onKeyDown={(e) => e.key === "Enter" && handleJoin()}
            className="h-11 bg-white/5 border-white/10 text-white placeholder:text-white/30"
          />
          {error && <p className="text-red-400 text-xs px-0.5">{error}</p>}
        </div>

        <div className="flex gap-2">
          <Button variant="ghost" className="flex-1 h-11 text-white/60 hover:text-white" onClick={onClose}>
            Cancel
          </Button>
          <Button className="flex-1 h-11" onClick={handleJoin}>
            Join Call
            <ArrowRight className="ml-2 w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}

// ─── Home page ─────────────────────────────────────────────────────────────────

export default function Home() {
  const [showCreate, setShowCreate] = useState(false);
  const [joiningRoom, setJoiningRoom] = useState<{ code: string; roomName: string; participantCount: number } | null>(null);

  const { data: rooms = [], isLoading, refetch, isRefetching } = useListRooms({
    query: { queryKey: getListRoomsQueryKey(), refetchInterval: 5000 },
  });

  return (
    <div className="min-h-[100dvh] bg-background flex flex-col">
      {/* Top nav */}
      <header className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b border-border/50 bg-background/80 backdrop-blur-md">
        <div className="flex items-center gap-2.5">
          <div className="bg-primary/15 p-1.5 rounded-lg">
            <Video className="w-5 h-5 text-primary" />
          </div>
          <span className="text-lg font-bold tracking-tight">CallConnect</span>
        </div>
        <Button onClick={() => setShowCreate(true)} className="gap-2 h-9 px-4 shadow-lg shadow-primary/20">
          <Plus className="w-4 h-4" />
          Create Room
        </Button>
      </header>

      {/* Room list */}
      <main className="flex-1 max-w-2xl w-full mx-auto px-4 py-8 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Active Rooms</h1>
            <p className="text-muted-foreground text-sm mt-0.5">Click a room to join the call</p>
          </div>
          <button
            onClick={() => refetch()}
            className="text-muted-foreground hover:text-foreground transition-colors p-2 rounded-lg hover:bg-accent"
            title="Refresh"
          >
            <RefreshCw className={`w-4 h-4 ${isRefetching ? "animate-spin" : ""}`} />
          </button>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
          </div>
        ) : rooms.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-24 text-center space-y-4">
            <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
              <Video className="w-8 h-8 text-primary/60" />
            </div>
            <div>
              <p className="text-lg font-medium">No active rooms</p>
              <p className="text-muted-foreground text-sm mt-1">Be the first — create a room above</p>
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            {rooms.map((room) => (
              <button
                key={room.code}
                onClick={() => setJoiningRoom({ code: room.code, roomName: room.roomName, participantCount: room.participantCount })}
                className="w-full flex items-center justify-between p-4 rounded-xl border border-border/60 bg-card/40 hover:bg-card/80 hover:border-primary/40 hover:shadow-md transition-all text-left group"
              >
                <div className="space-y-1 min-w-0">
                  <p className="font-semibold text-foreground truncate">{room.roomName}</p>
                  <p className="text-sm text-muted-foreground truncate">
                    hosted by {room.hostName}
                  </p>
                </div>
                <div className="flex items-center gap-4 shrink-0 ml-4">
                  <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                    <div className={`w-2 h-2 rounded-full ${room.participantCount > 0 ? "bg-green-400" : "bg-yellow-400"}`} />
                    <Users className="w-3.5 h-3.5" />
                    <span>{room.participantCount}</span>
                  </div>
                  <ArrowRight className="w-4 h-4 text-muted-foreground group-hover:text-primary group-hover:translate-x-0.5 transition-all" />
                </div>
              </button>
            ))}
          </div>
        )}
      </main>

      <footer className="text-center text-xs text-muted-foreground pb-6">
        Peer-to-peer encrypted connection. No middleman.
      </footer>

      {showCreate && <CreateRoomModal onClose={() => setShowCreate(false)} />}
      {joiningRoom && (
        <JoinModal
          roomCode={joiningRoom.code}
          roomName={joiningRoom.roomName}
          participantCount={joiningRoom.participantCount}
          onClose={() => setJoiningRoom(null)}
        />
      )}
    </div>
  );
}
