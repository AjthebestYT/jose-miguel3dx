import { useEffect, useRef, useState, useMemo } from "react";
import { useParams, useLocation } from "wouter";
import { useGetRoom, getGetRoomQueryKey } from "@workspace/api-client-react";
import { useWebRTC, type RemotePeer, type ChatMessage } from "@/hooks/use-webrtc";
import { Button } from "@/components/ui/button";
import {
  Mic, MicOff, Video as VideoIcon, VideoOff,
  PhoneOff, Copy, Check, Users, MessageSquare, Send, X,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Card } from "@/components/ui/card";

// ─── Video tile ────────────────────────────────────────────────────────────────

interface VideoTileProps {
  stream: MediaStream | null;
  label: string;
  muted?: boolean;
  isCameraOff?: boolean;
  isMicOff?: boolean;
  mirrored?: boolean;
}

function VideoTile({ stream, label, muted = false, isCameraOff = false, isMicOff = false, mirrored = false }: VideoTileProps) {
  const ref = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (ref.current && stream) {
      ref.current.srcObject = stream;
    }
  }, [stream]);

  return (
    <div className="relative w-full h-full bg-zinc-900 rounded-xl overflow-hidden border border-white/10 shadow-lg">
      {stream && !isCameraOff ? (
        <video
          ref={ref}
          autoPlay
          playsInline
          muted={muted}
          className={`w-full h-full object-cover ${mirrored ? "scale-x-[-1]" : ""}`}
        />
      ) : (
        <div className="absolute inset-0 flex items-center justify-center bg-zinc-900">
          <div className="w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center">
            <span className="text-2xl font-bold text-primary">
              {label.charAt(0).toUpperCase()}
            </span>
          </div>
        </div>
      )}
      <div className="absolute bottom-2 left-2 px-2 py-1 bg-black/60 backdrop-blur-md rounded text-xs font-medium text-white flex items-center gap-1">
        {label}
        {isMicOff && <MicOff className="w-3 h-3 text-red-400" />}
      </div>
    </div>
  );
}

// ─── Participant grid ───────────────────────────────────────────────────────────

function ParticipantGrid({ localStream, remoteStreams, userName, isMuted, isCameraOff }: {
  localStream: MediaStream | null;
  remoteStreams: Map<string, RemotePeer>;
  userName: string;
  isMuted: boolean;
  isCameraOff: boolean;
}) {
  const count = 1 + remoteStreams.size;
  const remoteEntries = useMemo(() => Array.from(remoteStreams.entries()), [remoteStreams]);

  const gridClass = useMemo(() => {
    if (count === 1) return "grid-cols-1";
    if (count === 2) return "grid-cols-2";
    if (count <= 4) return "grid-cols-2";
    return "grid-cols-3";
  }, [count]);

  return (
    <div className={`grid ${gridClass} gap-2 w-full h-full p-2`}>
      <VideoTile
        stream={localStream}
        label={`${userName} (You)`}
        muted
        isCameraOff={isCameraOff}
        isMicOff={isMuted}
        mirrored
      />
      {remoteEntries.map(([peerId, peer]) => (
        <VideoTile key={peerId} stream={peer.stream} label={peer.userName} />
      ))}
    </div>
  );
}

// ─── Chat panel ────────────────────────────────────────────────────────────────

function ChatPanel({ messages, onSend, onClose, userName }: {
  messages: ChatMessage[];
  onSend: (text: string) => void;
  onClose: () => void;
  userName: string;
}) {
  const [draft, setDraft] = useState("");
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const handleSend = () => {
    if (!draft.trim()) return;
    onSend(draft);
    setDraft("");
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const formatTime = (ts: number) => {
    const d = new Date(ts);
    return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  };

  return (
    <div className="flex flex-col h-full bg-zinc-950/95 border-l border-white/10 w-72 shrink-0">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-white/10">
        <div className="flex items-center gap-2">
          <MessageSquare className="w-4 h-4 text-primary" />
          <span className="text-white text-sm font-semibold">Chat</span>
        </div>
        <button
          onClick={onClose}
          className="text-white/50 hover:text-white transition-colors rounded-md p-1"
          data-testid="button-close-chat"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-3 space-y-3 min-h-0">
        {messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center py-8">
            <MessageSquare className="w-8 h-8 text-white/20 mb-2" />
            <p className="text-white/40 text-xs">No messages yet. Say hello!</p>
          </div>
        ) : (
          messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex flex-col ${msg.isSelf ? "items-end" : "items-start"}`}
              data-testid={`chat-message-${msg.id}`}
            >
              {!msg.isSelf && (
                <span className="text-[10px] text-white/40 mb-1 px-1">{msg.userName}</span>
              )}
              <div
                className={`max-w-[85%] px-3 py-2 rounded-2xl text-sm leading-snug break-words ${
                  msg.isSelf
                    ? "bg-primary text-white rounded-br-sm"
                    : "bg-white/10 text-white/90 rounded-bl-sm"
                }`}
              >
                {msg.text}
              </div>
              <span className="text-[10px] text-white/30 mt-1 px-1">
                {formatTime(msg.timestamp)}
              </span>
            </div>
          ))
        )}
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div className="p-3 border-t border-white/10">
        <div className="flex items-center gap-2 bg-white/10 rounded-xl px-3 py-2">
          <input
            ref={inputRef}
            type="text"
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Message..."
            className="flex-1 bg-transparent text-white text-sm placeholder:text-white/30 outline-none min-w-0"
            data-testid="input-chat-message"
          />
          <button
            onClick={handleSend}
            disabled={!draft.trim()}
            className="text-primary hover:text-primary/80 disabled:opacity-30 transition-colors shrink-0"
            data-testid="button-send-chat"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Name entry (for guests who arrive via link) ───────────────────────────────

function NameEntry({ onJoin }: { onJoin: (name: string) => void }) {
  const [name, setName] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = () => {
    if (!name.trim()) { setError("Please enter your name."); return; }
    onJoin(name.trim());
  };

  return (
    <div className="min-h-[100dvh] bg-background flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-sm space-y-6 animate-in fade-in slide-in-from-bottom-6 duration-500">
        <div className="text-center space-y-2">
          <div className="bg-primary/10 p-3 rounded-2xl inline-block mb-1">
            <Users className="w-8 h-8 text-primary" />
          </div>
          <h1 className="text-2xl font-bold">Join the call</h1>
          <p className="text-muted-foreground text-sm">Enter your name so others can see you</p>
        </div>
        <div className="space-y-3">
          <input
            autoFocus
            type="text"
            placeholder="Your name"
            value={name}
            onChange={(e) => { setName(e.target.value); setError(""); }}
            onKeyDown={(e) => e.key === "Enter" && handleSubmit()}
            className="w-full h-12 px-4 rounded-xl border border-border bg-background/60 text-foreground placeholder:text-muted-foreground outline-none focus:ring-2 focus:ring-primary/50 transition-all text-sm"
          />
          {error && <p className="text-red-400 text-xs px-1">{error}</p>}
          <button
            onClick={handleSubmit}
            className="w-full h-12 rounded-xl bg-primary hover:bg-primary/90 text-white font-medium transition-all shadow-lg shadow-primary/20"
          >
            Continue
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Room page ─────────────────────────────────────────────────────────────────

export default function Room() {
  const params = useParams();
  const roomCode = params.code || "";
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const [userName, setUserName] = useState("");
  const [copied, setCopied] = useState(false);
  const [isReady, setIsReady] = useState(false);
  const [chatOpen, setChatOpen] = useState(false);
  const [unread, setUnread] = useState(0);
  const [needsName, setNeedsName] = useState(false);

  const localVideoPreviewRef = useRef<HTMLVideoElement>(null);

  const { data: roomInfo, isLoading: isLoadingRoom, isError: isRoomError } = useGetRoom(roomCode, {
    query: {
      enabled: !!roomCode,
      queryKey: getGetRoomQueryKey(roomCode),
    },
  });

  const {
    localStream,
    remoteStreams,
    connectionState,
    error: rtcError,
    isMuted,
    isCameraOff,
    messages,
    initializeMedia,
    connect,
    leaveCall,
    toggleMute,
    toggleCamera,
    sendChatMessage,
  } = useWebRTC({ roomCode, userName });

  // Track unread messages when chat is closed
  const prevMsgCountRef = useRef(0);
  useEffect(() => {
    if (!chatOpen && messages.length > prevMsgCountRef.current) {
      setUnread((u) => u + (messages.length - prevMsgCountRef.current));
    }
    prevMsgCountRef.current = messages.length;
  }, [messages, chatOpen]);

  const handleOpenChat = () => {
    setChatOpen(true);
    setUnread(0);
  };

  useEffect(() => {
    const storedName = sessionStorage.getItem("callConnectUserName");
    if (!storedName) {
      setNeedsName(true);
    } else {
      setUserName(storedName);
      initializeMedia();
    }
  }, [initializeMedia]);

  const handleNameSubmit = (name: string) => {
    sessionStorage.setItem("callConnectUserName", name);
    setUserName(name);
    setNeedsName(false);
    initializeMedia();
  };

  useEffect(() => {
    if (localVideoPreviewRef.current && localStream) {
      localVideoPreviewRef.current.srcObject = localStream;
    }
  }, [localStream]);

  const handleCopyCode = () => {
    navigator.clipboard.writeText(roomCode);
    setCopied(true);
    toast({ title: "Copied!", description: "Room code copied to clipboard." });
    setTimeout(() => setCopied(false), 2000);
  };

  const handleJoin = () => {
    setIsReady(true);
    connect();
  };

  const handleLeave = () => {
    leaveCall();
    setLocation("/");
  };

  // ── Loading / error screens ────────────────────────────────────────────────

  if (needsName) {
    return <NameEntry onJoin={handleNameSubmit} />;
  }

  if (isLoadingRoom) {
    return (
      <div className="min-h-[100dvh] flex items-center justify-center bg-background">
        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (isRoomError || !roomInfo) {
    return (
      <div className="min-h-[100dvh] flex flex-col items-center justify-center bg-background p-4 text-center">
        <h2 className="text-2xl font-bold mb-2">Room not found</h2>
        <p className="text-muted-foreground mb-6">This room may have expired or never existed.</p>
        <Button onClick={() => setLocation("/")}>Go Home</Button>
      </div>
    );
  }

  // ── Pre-call lobby ─────────────────────────────────────────────────────────

  if (!isReady) {
    return (
      <div className="min-h-[100dvh] bg-background flex flex-col items-center justify-center p-4">
        <div className="w-full max-w-4xl grid md:grid-cols-2 gap-8 items-center">
          <div className="space-y-6">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold">Ready to join?</h1>
              <p className="text-muted-foreground">
                Room <span className="font-mono font-bold text-primary">{roomCode}</span> — anyone with this code can join.
              </p>
            </div>
            <div className="flex flex-col gap-3">
              <Button size="lg" className="w-full h-14 text-lg" onClick={handleJoin} data-testid="button-join-call">
                Join Call
              </Button>
              <Button variant="secondary" size="lg" className="w-full h-14" onClick={handleCopyCode} data-testid="button-copy-code">
                {copied ? <Check className="mr-2 h-4 w-4" /> : <Copy className="mr-2 h-4 w-4" />}
                Copy Room Code
              </Button>
              <Button variant="ghost" className="w-full" onClick={() => setLocation("/")}>
                Cancel
              </Button>
            </div>
          </div>

          <Card className="overflow-hidden bg-black/90 aspect-video relative rounded-2xl border-border/50 shadow-2xl">
            {localStream ? (
              <video ref={localVideoPreviewRef} autoPlay playsInline muted className="w-full h-full object-cover scale-x-[-1]" />
            ) : (
              <div className="absolute inset-0 flex items-center justify-center">
                <p className="text-white/50 text-sm">Starting camera...</p>
              </div>
            )}
            <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-4">
              <Button
                variant={isMuted ? "destructive" : "secondary"}
                size="icon"
                className="rounded-full h-12 w-12 bg-background/80 backdrop-blur-md"
                onClick={toggleMute}
                data-testid="button-toggle-mute-preview"
              >
                {isMuted ? <MicOff /> : <Mic />}
              </Button>
              <Button
                variant={isCameraOff ? "destructive" : "secondary"}
                size="icon"
                className="rounded-full h-12 w-12 bg-background/80 backdrop-blur-md"
                onClick={toggleCamera}
                data-testid="button-toggle-camera-preview"
              >
                {isCameraOff ? <VideoOff /> : <VideoIcon />}
              </Button>
            </div>
          </Card>
        </div>
      </div>
    );
  }

  // ── Error / ended ──────────────────────────────────────────────────────────

  if (connectionState === "error" || connectionState === "call-ended") {
    return (
      <div className="min-h-[100dvh] bg-background flex flex-col items-center justify-center p-4 text-center">
        <div className="w-16 h-16 bg-red-500/20 rounded-full flex items-center justify-center mb-6">
          <PhoneOff className="w-8 h-8 text-red-500" />
        </div>
        <h2 className="text-3xl font-bold mb-2">
          {connectionState === "call-ended" ? "Call ended" : "Connection Error"}
        </h2>
        <p className="text-muted-foreground mb-8">
          {connectionState === "error" ? rtcError || "Something went wrong." : "You left the call."}
        </p>
        <Button size="lg" onClick={handleLeave}>Return to Home</Button>
      </div>
    );
  }

  // ── Active call ────────────────────────────────────────────────────────────

  return (
    <div className="min-h-[100dvh] bg-black flex flex-col" data-testid="call-room">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 bg-black/60 backdrop-blur-md border-b border-white/10 z-10 shrink-0">
        <div className="flex items-center gap-2 text-white/70 text-sm">
          <Users className="w-4 h-4" />
          <span data-testid="participant-count">{1 + remoteStreams.size} in call</span>
        </div>
        <button
          onClick={handleCopyCode}
          className="flex items-center gap-2 bg-white/10 hover:bg-white/20 transition-colors px-3 py-1.5 rounded-full cursor-pointer"
          data-testid="button-copy-code-call"
        >
          <span className="text-white/80 font-mono text-sm tracking-widest">{roomCode}</span>
          {copied ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5 text-white/50" />}
        </button>
      </div>

      {/* Main area: videos + optional chat panel */}
      <div className="flex flex-1 min-h-0">
        {/* Video area */}
        <div className="flex-1 relative min-w-0">
          {connectionState === "waiting" && remoteStreams.size === 0 ? (
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center space-y-4 px-4">
              <div className="w-20 h-20 bg-primary/20 rounded-full flex items-center justify-center mb-2">
                <Users className="w-10 h-10 text-primary" />
              </div>
              <h2 className="text-2xl font-medium text-white">Waiting for others...</h2>
              <p className="text-white/60 text-sm">Share the code above to invite people</p>
              <div className="mt-4 w-48 aspect-video bg-zinc-900 rounded-xl overflow-hidden border border-white/10">
                <VideoTile
                  stream={localStream}
                  label={`${userName} (You)`}
                  muted
                  isCameraOff={isCameraOff}
                  isMicOff={isMuted}
                  mirrored
                />
              </div>
            </div>
          ) : (
            <ParticipantGrid
              localStream={localStream}
              remoteStreams={remoteStreams}
              userName={userName}
              isMuted={isMuted}
              isCameraOff={isCameraOff}
            />
          )}
        </div>

        {/* Chat panel (slide in) */}
        {chatOpen && (
          <ChatPanel
            messages={messages}
            onSend={sendChatMessage}
            onClose={() => setChatOpen(false)}
            userName={userName}
          />
        )}
      </div>

      {/* Controls bar */}
      <div className="flex justify-center items-center gap-3 py-5 bg-black/60 backdrop-blur-md border-t border-white/10 shrink-0">
        <Button
          variant={isMuted ? "destructive" : "secondary"}
          size="icon"
          className={`rounded-full h-14 w-14 transition-all ${!isMuted ? "bg-white/10 hover:bg-white/20 text-white border-none" : ""}`}
          onClick={toggleMute}
          data-testid="button-toggle-mute"
        >
          {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
        </Button>

        <Button
          variant={isCameraOff ? "destructive" : "secondary"}
          size="icon"
          className={`rounded-full h-14 w-14 transition-all ${!isCameraOff ? "bg-white/10 hover:bg-white/20 text-white border-none" : ""}`}
          onClick={toggleCamera}
          data-testid="button-toggle-camera"
        >
          {isCameraOff ? <VideoOff className="w-5 h-5" /> : <VideoIcon className="w-5 h-5" />}
        </Button>

        {/* Chat toggle with unread badge */}
        <div className="relative">
          <Button
            variant={chatOpen ? "secondary" : "secondary"}
            size="icon"
            className={`rounded-full h-14 w-14 transition-all ${chatOpen ? "bg-primary/20 text-primary border-primary/30" : "bg-white/10 hover:bg-white/20 text-white border-none"}`}
            onClick={chatOpen ? () => setChatOpen(false) : handleOpenChat}
            data-testid="button-toggle-chat"
          >
            <MessageSquare className="w-5 h-5" />
          </Button>
          {unread > 0 && !chatOpen && (
            <span className="absolute -top-1 -right-1 bg-primary text-white text-[10px] font-bold rounded-full w-5 h-5 flex items-center justify-center">
              {unread > 9 ? "9+" : unread}
            </span>
          )}
        </div>

        <div className="w-px h-8 bg-white/10 mx-1" />

        <Button
          variant="destructive"
          size="icon"
          className="rounded-full h-14 w-14 bg-red-500 hover:bg-red-600 border-none shadow-lg shadow-red-500/20"
          onClick={handleLeave}
          data-testid="button-hang-up"
        >
          <PhoneOff className="w-5 h-5" />
        </Button>
      </div>
    </div>
  );
}
