import { Router, type IRouter } from "express";
import { CreateRoomBody, GetRoomParams, GetRoomResponse } from "@workspace/api-zod";
import { createRoom, getRoom, listRooms } from "../lib/rooms";

const router: IRouter = Router();

router.get("/rooms", async (_req, res): Promise<void> => {
  const rooms = listRooms();
  res.json(rooms.map((r) => GetRoomResponse.parse(r)));
});

router.post("/rooms", async (req, res): Promise<void> => {
  const parsed = CreateRoomBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const room = createRoom(parsed.data.hostName, parsed.data.roomName);
  res.status(201).json(GetRoomResponse.parse(room));
});

router.get("/rooms/:code", async (req, res): Promise<void> => {
  const params = GetRoomParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const room = getRoom(params.data.code);
  if (!room) {
    res.status(404).json({ error: "Room not found" });
    return;
  }

  res.json(GetRoomResponse.parse(room));
});

export default router;
