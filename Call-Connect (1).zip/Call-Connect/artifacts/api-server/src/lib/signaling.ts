import { WebSocketServer, WebSocket } from "ws";
import type { Server } from "http";
import { logger } from "./logger";
import { getRoom, incrementParticipants, decrementParticipants } from "./rooms";
import { randomUUID } from "crypto";

interface Client {
  id: string;
  ws: WebSocket;
  roomCode: string;
  userName: string;
}

const roomClients = new Map<string, Client[]>();

export function setupSignaling(server: Server): void {
  const wss = new WebSocketServer({ noServer: true });
  const heartbeatInterval = setInterval(() => {
    for (const ws of wss.clients) {
      if (ws.readyState === WebSocket.OPEN) {
        ws.ping();
      }
    }
  }, 25_000);

  server.on("close", () => {
    clearInterval(heartbeatInterval);
  });

  server.on("upgrade", (request, socket, head) => {
    const url = request.url || "";
    if (url === "/api/ws" || url.startsWith("/api/ws?")) {
      wss.handleUpgrade(request, socket, head, (ws) => {
        wss.emit("connection", ws, request);
      });
    } else {
      socket.destroy();
    }
  });

  wss.on("connection", (ws) => {
    let client: Client | null = null;

    ws.on("message", (raw) => {
      let msg: Record<string, unknown>;
      try {
        msg = JSON.parse(raw.toString());
      } catch {
        return;
      }

      const type = msg.type as string;

      if (type === "keepalive") {
        if (ws.readyState === WebSocket.OPEN) {
          ws.send(JSON.stringify({ type: "keepalive-ack" }));
        }
        return;
      }

      if (type === "join") {
        const roomCode = msg.roomCode as string;
        const userName = msg.userName as string;

        if (!roomCode || !userName) return;

        const room = getRoom(roomCode);
        if (!room) {
          ws.send(JSON.stringify({ type: "error", message: "Room not found" }));
          return;
        }

        const id = randomUUID();
        client = { id, ws, roomCode, userName };

        const existing = roomClients.get(roomCode) || [];

        // Send new peer their ID and list of existing peers so they can initiate connections
        ws.send(
          JSON.stringify({
            type: "welcome",
            peerId: id,
            peers: existing.map((c) => ({ id: c.id, userName: c.userName })),
          })
        );

        existing.push(client);
        roomClients.set(roomCode, existing);
        incrementParticipants(roomCode);

        logger.info({ roomCode, userName, id }, "User joined room");

        // Notify all existing peers that a new user joined
        for (const other of existing) {
          if (other.ws !== ws && other.ws.readyState === WebSocket.OPEN) {
            other.ws.send(
              JSON.stringify({
                type: "user-joined",
                peerId: id,
                userName,
              })
            );
          }
        }
      } else if (
        type === "offer" ||
        type === "answer" ||
        type === "ice-candidate"
      ) {
        if (!client) return;
        const to = msg.to as string;
        const clients = roomClients.get(client.roomCode) || [];
        const target = clients.find((c) => c.id === to);
        if (target && target.ws.readyState === WebSocket.OPEN) {
          target.ws.send(
            JSON.stringify({ ...msg, from: client.id })
          );
        }
      } else if (type === "chat") {
        if (!client) return;
        const text = (msg.text as string || "").trim();
        if (!text) return;
        const payload = JSON.stringify({
          type: "chat",
          from: client.id,
          userName: client.userName,
          text,
          timestamp: Date.now(),
        });
        const clients = roomClients.get(client.roomCode) || [];
        for (const other of clients) {
          if (other.ws !== ws && other.ws.readyState === WebSocket.OPEN) {
            other.ws.send(payload);
          }
        }
      }
    });

    ws.on("close", () => {
      if (!client) return;
      const { id, roomCode, userName } = client;
      const clients = roomClients.get(roomCode) || [];
      const filtered = clients.filter((c) => c.ws !== ws);
      if (filtered.length === 0) {
        roomClients.delete(roomCode);
      } else {
        roomClients.set(roomCode, filtered);
      }
      decrementParticipants(roomCode);

      for (const other of filtered) {
        if (other.ws.readyState === WebSocket.OPEN) {
          other.ws.send(JSON.stringify({ type: "user-left", peerId: id, userName }));
        }
      }

      logger.info({ roomCode, userName, id }, "User left room");
    });
  });

  logger.info("WebSocket signaling server initialized");
}
