import { logger } from "./logger";

export interface RoomInfo {
  code: string;
  hostName: string;
  roomName: string;
  createdAt: string;
  participantCount: number;
}

const rooms = new Map<string, RoomInfo>();

function generateCode(): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "";
  for (let i = 0; i < 6; i++) {
    code += chars[Math.floor(Math.random() * chars.length)];
  }
  return code;
}

export function createRoom(hostName: string, roomName: string): RoomInfo {
  let code = generateCode();
  while (rooms.has(code)) {
    code = generateCode();
  }

  const room: RoomInfo = {
    code,
    hostName,
    roomName,
    createdAt: new Date().toISOString(),
    participantCount: 0,
  };

  rooms.set(code, room);
  logger.info({ code, hostName, roomName }, "Room created");
  return room;
}

export function getRoom(code: string): RoomInfo | undefined {
  return rooms.get(code);
}

export function listRooms(): RoomInfo[] {
  return Array.from(rooms.values()).sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );
}

export function incrementParticipants(code: string): void {
  const room = rooms.get(code);
  if (room) {
    room.participantCount++;
  }
}

export function decrementParticipants(code: string): void {
  const room = rooms.get(code);
  if (room) {
    room.participantCount--;
    if (room.participantCount <= 0) {
      rooms.delete(code);
      logger.info({ code }, "Room removed (empty)");
    }
  }
}
