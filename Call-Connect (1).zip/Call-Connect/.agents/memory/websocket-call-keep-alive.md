---
name: WebSocket call keep-alive
description: Environment-specific guidance for long-running peer-to-peer calls.
---

Long-running calls should keep their signaling WebSocket active with periodic browser-to-server application messages and server WebSocket pings.

**Why:** Media flows peer-to-peer separately from signaling, so a call can look active while an intermediary considers the signaling socket idle and closes it after several minutes.

**How to apply:** Use a keep-alive interval shorter than the intermediary's idle window, clear it whenever the socket closes or the call ends, and ensure the server accepts and acknowledges the application-level message.