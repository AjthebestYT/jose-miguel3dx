# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Each package manages its own dependencies.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM (available but not currently used)
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)
- **WebRTC**: Peer-to-peer video/audio calling
- **WebSocket**: `ws` library for signaling server

## App: CallConnect (Video Calling)

A peer-to-peer video calling web app. Users create or join rooms with a 6-character code, then have real-time video and audio calls via WebRTC.

### Architecture
- **Frontend** (`artifacts/call-app`): React + Vite app with WebRTC integration
- **Backend** (`artifacts/api-server`): Express server with:
  - REST API for room creation/lookup (`/api/rooms`)
  - WebSocket signaling server at `/api/ws` for WebRTC signaling (offer/answer/ICE candidate exchange)
- **Rooms**: Managed in-memory (no database needed). Rooms are ephemeral and removed when empty.
- **Max 2 participants** per room (1-on-1 calls)

### Key Files
- `artifacts/api-server/src/lib/rooms.ts` — Room management (in-memory)
- `artifacts/api-server/src/lib/signaling.ts` — WebSocket signaling server
- `artifacts/api-server/src/routes/rooms.ts` — REST endpoints for rooms
- `artifacts/call-app/src/hooks/use-webrtc.ts` — WebRTC hook (peer connection, media streams)
- `artifacts/call-app/src/pages/home.tsx` — Lobby/home page
- `artifacts/call-app/src/pages/room.tsx` — Active call room

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — run API server locally

See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details.
